<footer>
        <div class="border-top mt-5 pt-lg-4 pt-3 pb-lg-0 pb-3 text-center">
          <p class="copy-right-grids mt-lg-1">Designed by Braham || Copyright ©  Blood Bank Donor Management System
          </p>
        </div>
  </footer>
  <!-- //footer -->